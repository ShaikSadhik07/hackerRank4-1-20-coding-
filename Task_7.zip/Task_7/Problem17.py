# Separate the Numbers

# https://www.hackerrank.com/challenges/separate-the-numbers/problem

#A numeric string, s, is beautiful if it can be split into a sequence of two or more positive integers, a1, a2, ..., an, satisfying the following conditions:
# 1. a[i] - a[i-1] = 1 for all i > 1
# 2. All integers in the sequence are positive
# 3. The sequence has at least two integers


import math
import os
import random
import re
import sys

#
# Complete the 'separateNumbers' function below.
#
# The function accepts STRING s as parameter.
#

def separateNumbers(s):
    # Write your code here
    n = len(s)
    # The first number can at most be half the length of the string
    for i in range(1, n // 2 + 1):
        first_str = s[:i]
        
        # Numbers cannot have leading zeros
        if first_str[0] == '0':
            break
            
        num = int(first_str)
        current_str = first_str
        
        # Build the sequence until it matches or exceeds the length of s
        while len(current_str) < n:
            num += 1
            current_str += str(num)
            
        # If the constructed sequence matches s, it's beautiful
        if current_str == s:
            print(f"YES {first_str}")
            return
            
    print("NO")

if __name__ == '__main__':
    q = int(input().strip())

    for q_itr in range(q):
        s = input()

        separateNumbers(s)