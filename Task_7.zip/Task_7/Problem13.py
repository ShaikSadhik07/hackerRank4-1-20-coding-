# Sherlock and the Valid String

# https://www.hackerrank.com/challenges/sherlock-and-valid-string/problem

# Sherlock considers a string to be valid if all characters of the string appear the same number of times. It is also valid if he can remove just 1 character at 1 index in the string, and the remaining characters will occur the same number of times. Given a string s, determine if it is valid. If so, return YES, otherwise return NO.



import math
import os
import random
import re
import sys

#
# Complete the 'isValid' function below.
#
# The function is expected to return a STRING.
# The function accepts STRING s as parameter.
#
from collections import Counter
def isValid(s):
    # Write your code here
    char_count = Counter(s)
    freq_count = Counter(char_count.values())
    if len(freq_count) == 1:
        return "YES"
    
    if len(freq_count) == 2:
        freqs = list(freq_count.keys())
        counts = list(freq_count.values())
        
        freqs.sort()
        f1, f2 = freqs[0], freqs[1]
        c1, c2 = freq_count[f1], freq_count[f2]
        
        if f1 == 1 and c1 == 1:
            return "YES"
        
        if f2 - f1 == 1 and c2 == 1:
            return "YES"
            
    return "NO"

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = isValid(s)

    fptr.write(result + '\n')

    fptr.close()