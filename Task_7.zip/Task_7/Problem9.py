# Beautiful Binary String

# https://www.hackerrank.com/challenges/beautiful-binary-string/problem

# Alice has a binary string. She thinks a binary string is beautiful if and only if it doesn't contain the substring "010".

#In one step, Alice can change a 0 to a 1 or vice versa. Count and print the minimum number of steps needed to make Alice see the string as beautiful.


import math
import os
import random
import re
import sys

#
# Complete the 'beautifulBinaryString' function below.
#
# The function is expected to return an INTEGER.
# The function accepts STRING b as parameter.
#

def beautifulBinaryString(b):
    # Write your code here
    count = 0
    i = 0
    while i <= len(b) - 3:
        if b[i:i+3] == "010":
            count += 1
            i += 3  # Skip past the matched "010" to avoid overlapping counts
        else:
            i += 1
    return count

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    n = int(input().strip())

    b = input()

    result = beautifulBinaryString(b)

    fptr.write(str(result) + '\n')

    fptr.close()