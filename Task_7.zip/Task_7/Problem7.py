# Alphabet Rangoli

# https://www.hackerrank.com/challenges/alphabet-rangoli/problem

# You are given an integer N. Your task is to print an alphabet rangoli of size N.

import string

def print_rangoli(size):
    alpha = string.ascii_lowercase
    lines = []
    
    for i in range(size - 1, -1, -1):
        row_chars = [alpha[j] for j in range(size - 1, i, -1)] + [alpha[j] for j in range(i, size)]
        row_str = "-".join(row_chars)
        lines.append(row_str.center(4 * size - 3, '-'))
    full_rangoli = lines + lines[:-1][::-1]
    print('\n'.join(full_rangoli))

if __name__ == '__main__':
    n = int(input())
    print_rangoli(n)