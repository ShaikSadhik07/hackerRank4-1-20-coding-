# Making Anagrams

# https://www.hackerrank.com/challenges/making-anagrams/problem

# We consider two strings to be anagrams of each other if the first string's letters can be rearranged to form the second string. In other words, both strings must contain the same exact letters in the same exact frequency. For example, bacdc and dcbac are anagrams, but bacdc and dcbad are not.

#Alice is taking a cryptography class and finding anagrams to be very useful. She decides on an encryption scheme involving two large strings where encryption is dependent on the minimum number of character deletions required to make the two strings anagrams. Can you help her find this number?

#Given two strings, S1 and S2, that may not be of the same length, determine the minimum number of character deletions required to make S1 and S2 anagrams. Any characters can be deleted from either of the strings.


import math
import os
import random
import re
import sys

#
# Complete the 'makingAnagrams' function below.
#
# The function is expected to return an INTEGER.
# The function accepts following parameters:
#  1. STRING s1
#  2. STRING s2
#
from collections import Counter
def makingAnagrams(s1, s2):
    # Write your code here
    c1 = Counter(s1)
    c2 = Counter(s2)
    diff = (c1 - c2) + (c2 - c1)
    return sum(diff.values())

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s1 = input()

    s2 = input()

    result = makingAnagrams(s1, s2)

    fptr.write(str(result) + '\n')

    fptr.close()
